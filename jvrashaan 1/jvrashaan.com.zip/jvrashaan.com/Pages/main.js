$(document).ready(function(){
  //Home page




  //About me Page
  $('#myphoto').hide();
  $('.table').hide();
  $('#bu').hide();
  $('#myphoto').fadeIn(2000);
  $('.table').fadeIn(2000);
  $('#bu').fadeIn(2000);

});
